
  "Domino" MIDI/Music Editor Software
  Copyright (C) 2007-2020 Takabo Soft (http://takabosoft.com/)

Thank you very much for downloading Domino!
Please read the User Manual for details which can be found in the following directory: 
Manual/index.htm

(Alternatively, you can open the User Manual by pressing the [F1] key within the application.)
