Domino English Translation 
Build 4 (1.43-en.4)

Thank you for using the Domino English Translation.

Domino is a MIDI editor that is used for creating MIDI songs/musics. Domino is used by various blackers in the Black MIDI ecosystem.

Since Domino is an abandonware, and it's original language is Japanese, many people tried to translate it using resource editing tools. Some of it are outdated, while others are incomplete.

This project is made to unify the translations made by community, while trying to complete it for easier usage.

You can download the latest version or even contribute by clicking the links below.

Repository      : https://github.com/Hans5958/Domino-English-Translation/
Releases        : https://github.com/Hans5958/Domino-English-Translation/releases
Domino site     : http://takabosoft.com/domino